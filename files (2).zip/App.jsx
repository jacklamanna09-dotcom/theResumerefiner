import { useState, useCallback } from 'react';

/* ─── constants ──────────────────────────────────────────────────────────── */
const NAV_PAGES = ['home', 'about', 'faq', 'contact'];

const FEATURES = [
  {
    title: 'Resume Optimization',
    description: 'Automatically cleans and formats your resume. Adds relevant keywords from job descriptions to help you pass applicant tracking systems (ATS).',
    icon: '✓',
  },
  {
    title: 'Cover Letter Generation',
    description: 'Creates professional, personalized cover letters in seconds. Friendly tone that makes a great impression on hiring managers.',
    icon: '✉️',
  },
  {
    title: 'Free & Safe',
    description: 'One free resume refinement per day. Your data is never stored or shared – processed securely via our backend.',
    icon: '🔒',
  },
];

const FAQ_ITEMS = [
  {
    question: 'Is this tool free?',
    answer:
      'Yes! Everyone can refine one resume per day for free. We believe students and first-time job seekers shouldn\'t have to pay to access basic career tools.',
  },
  {
    question: 'Do you store my resume or job description?',
    answer:
      'No. Your text is sent to our secure backend, processed by the AI, and the response is returned to you. Nothing is persisted.',
  },
  {
    question: 'Who can use this tool?',
    answer:
      'Students, first-time job seekers, or anyone applying to jobs. Our tool is specifically designed for people who might not have experience creating professional resumes and cover letters.',
  },
  {
    question: 'Do I need an account?',
    answer:
      'No account is required — just paste your resume and job description and start refining.',
  },
  {
    question: 'How does the AI refinement work?',
    answer:
      'Our AI analyzes the job description to identify key skills and requirements, then optimizes your resume with relevant keywords and professional phrasing. It also generates a personalized cover letter that highlights your most relevant qualifications.',
  },
];

/* ─── sub-components ─────────────────────────────────────────────────────── */
function Navigation({ currentPage, setCurrentPage, setIsMobileMenuOpen }) {
  return (
    <nav className="flex flex-col md:flex-row md:space-x-8 mt-4 md:mt-0">
      {NAV_PAGES.map((page) => (
        <button
          key={page}
          onClick={() => {
            setCurrentPage(page);
            setIsMobileMenuOpen(false);
          }}
          className={`text-lg font-medium py-2 px-1 transition-colors duration-200 ${
            currentPage === page
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-700 hover:text-blue-600'
          }`}
        >
          {page.charAt(0).toUpperCase() + page.slice(1)}
        </button>
      ))}
    </nav>
  );
}

function FAQItem({ question, answer }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
      <button
        onClick={() => setOpen((p) => !p)}
        className="w-full text-left bg-blue-50 px-6 py-4 flex items-center justify-between"
      >
        <span className="font-bold text-lg text-gray-800">Q: {question}</span>
        <span
          className="text-2xl text-blue-600 transition-transform duration-200 inline-block"
          style={{ transform: open ? 'rotate(45deg)' : 'rotate(0deg)' }}
        >
          +
        </span>
      </button>
      {open && (
        <div className="px-6 py-4 bg-white text-gray-700 text-lg leading-relaxed">
          A: {answer}
        </div>
      )}
    </div>
  );
}

/* ─── rate-limit helpers ─────────────────────────────────────────────────── */
const RATE_KEY = 'rr_last';

function canRefine() {
  try {
    const raw = sessionStorage.getItem(RATE_KEY);
    if (!raw) return true;
    return Date.now() - Number(raw) > 24 * 60 * 60 * 1000;
  } catch {
    return true;
  }
}

function markUsed() {
  try {
    sessionStorage.setItem(RATE_KEY, String(Date.now()));
  } catch {
    /* ignore */
  }
}

/* ─── App ────────────────────────────────────────────────────────────────── */
export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [resumeText, setResumeText] = useState('');
  const [jobText, setJobText] = useState('');
  const [refinedText, setRefinedText] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [status, setStatus] = useState('idle'); // idle | loading | error
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);

  const handleRefine = useCallback(async () => {
    if (!resumeText.trim() || !jobText.trim()) {
      alert('Please fill in both the resume and job description fields.');
      return;
    }
    if (!canRefine()) {
      setErrorMsg('You have already used your free refinement today. Please try again after 24 hours.');
      setStatus('error');
      return;
    }

    setRefinedText('');
    setStatus('loading');
    setErrorMsg('');

    try {
      const res = await fetch('/api/refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resume: resumeText, jobDescription: jobText }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Server error ${res.status}`);
      }

      const { result } = await res.json();
      setRefinedText(result);
      setStatus('idle');
      markUsed();
    } catch (err) {
      setErrorMsg(err.message || 'Something went wrong. Please try again.');
      setStatus('error');
    }
  }, [resumeText, jobText]);

  const handleCopy = () => {
    navigator.clipboard.writeText(refinedText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  /* ── render ────────────────────────────────────────────────────────────── */
  return (
    <div className="min-h-screen flex flex-col bg-white text-gray-800 font-sans">
      {/* header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between">
          <div
            className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700 cursor-pointer"
            onClick={() => { setCurrentPage('home'); setIsMobileMenuOpen(false); }}
          >
            Resume Refine
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen((p) => !p)}
              className="text-gray-700 text-2xl"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? '✕' : '☰'}
            </button>
          </div>
          <div className="hidden md:block">
            <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} setIsMobileMenuOpen={setIsMobileMenuOpen} />
          </div>
        </div>
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 py-4">
            <div className="container mx-auto px-4">
              <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} setIsMobileMenuOpen={setIsMobileMenuOpen} />
            </div>
          </div>
        )}
      </header>

      {/* ── main ── */}
      <main className="flex-grow">

        {/* HOME */}
        {currentPage === 'home' && (
          <div>
            {/* hero */}
            <section className="py-16 md:py-24 bg-gradient-to-b from-blue-50 to-white">
              <div className="container mx-auto px-4 text-center max-w-4xl">
                <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700">
                  Fix your resume and cover letter in seconds
                </h1>
                <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
                  Free AI tool for students and first-time job applicants
                </p>
                <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8 mb-12">
                  <h2 className="text-2xl font-bold mb-6 text-gray-800">How It Works:</h2>
                  <ol className="space-y-4 text-left max-w-2xl mx-auto">
                    {['Paste your resume', 'Paste the job description', 'Click "Refine My Resume"', 'Copy your optimized resume and cover letter'].map((step, i) => (
                      <li key={i} className="flex items-start">
                        <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold mr-4 mt-1">
                          {i + 1}
                        </div>
                        <span className="text-lg text-gray-700">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </section>

            {/* form */}
            <section className="py-12 md:py-16 bg-white">
              <div className="container mx-auto px-4 max-w-5xl">
                <div className="bg-gray-50 rounded-2xl shadow-md overflow-hidden">
                  <div className="p-6 md:p-8">
                    <div className="mb-8">
                      <label htmlFor="resume" className="block text-lg font-medium text-gray-800 mb-3">Paste your resume here</label>
                      <textarea id="resume" value={resumeText} onChange={(e) => setResumeText(e.target.value)} rows={10}
                        className="w-full border border-gray-300 rounded-xl p-4 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-200 resize-y"
                        placeholder="Copy and paste your resume text here…" />
                    </div>
                    <div className="mb-8">
                      <label htmlFor="job-desc" className="block text-lg font-medium text-gray-800 mb-3">Paste the job description here</label>
                      <textarea id="job-desc" value={jobText} onChange={(e) => setJobText(e.target.value)} rows={8}
                        className="w-full border border-gray-300 rounded-xl p-4 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-200 resize-y"
                        placeholder="Copy and paste the job description text here…" />
                    </div>

                    <button onClick={handleRefine} disabled={status === 'loading'}
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-bold py-4 px-8 rounded-xl hover:from-blue-700 hover:to-indigo-800 transition duration-300 text-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed">
                      {status === 'loading' ? 'Refining…' : 'Refine My Resume'}
                    </button>

                    {status === 'error' && (
                      <div className="mt-4 bg-red-50 border border-red-200 text-red-700 rounded-xl px-5 py-3 text-lg">{errorMsg}</div>
                    )}

                    {/* output */}
                    <div className="mt-10">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-gray-800 flex items-center">
                          <span className="mr-3">📄</span> Your refined resume &amp; cover letter:
                        </h3>
                        {refinedText && (
                          <button onClick={handleCopy}
                            className="text-sm font-semibold text-blue-600 hover:text-blue-800 border border-blue-200 hover:border-blue-400 px-4 py-1.5 rounded-lg transition duration-200">
                            {copied ? '✓ Copied!' : 'Copy'}
                          </button>
                        )}
                      </div>
                      <div className="border border-gray-200 rounded-xl p-6 bg-white" style={{ minHeight: 250 }}>
                        {refinedText ? (
                          <pre className="whitespace-pre-wrap text-gray-800 text-lg leading-relaxed max-h-[60vh] overflow-y-auto" style={{ fontFamily: 'inherit' }}>{refinedText}</pre>
                        ) : (
                          <div className="text-gray-500 text-lg flex flex-col items-center justify-center text-center py-12">
                            <div className="text-5xl mb-4">✨</div>
                            <p className="text-xl font-medium">Your refined resume &amp; cover letter will appear here</p>
                            <p className="mt-2 text-gray-600">Paste your resume and job description above, then click "Refine My Resume"</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* feature cards */}
            <section className="py-16 bg-gradient-to-b from-white to-blue-50">
              <div className="container mx-auto px-4 max-w-6xl">
                <div className="text-center mb-12">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Students Love Resume Refine</h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">Designed specifically for students and first-time job seekers</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {FEATURES.map((f, i) => (
                    <div key={i} className="bg-white rounded-2xl shadow-md p-8 hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                      <div className="text-4xl mb-4">{f.icon}</div>
                      <h3 className="text-2xl font-bold mb-3 text-gray-800">{f.title}</h3>
                      <p className="text-gray-600 text-lg leading-relaxed">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* ABOUT */}
        {currentPage === 'about' && (
          <section className="py-16 bg-white">
            <div className="container mx-auto px-4 max-w-4xl">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700">About Resume Refine</h1>
                <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-indigo-600 mx-auto rounded-full" />
              </div>
              <div className="text-gray-700 leading-relaxed">
                <p className="text-xl mb-6">Resume Refine is a free AI-powered tool designed to help students and first-time job applicants create professional resumes and cover letters instantly.</p>
                <p className="text-lg mb-6">We understand how stressful job applications can be, especially when you're just starting out. That's why we created a simple solution that takes the guesswork out of resume writing. Our AI analyzes job descriptions and optimizes your resume with relevant keywords and professional formatting.</p>
                <p className="text-lg mb-6">Our goal is to make applying for jobs faster, easier, and stress-free. We believe everyone deserves a fair chance at their dream job, regardless of their experience level or access to expensive resume services.</p>
                <p className="text-lg font-medium">Everything is processed securely through our backend, and your data is never stored or shared with third parties. Your privacy and security are our top priorities.</p>
              </div>
            </div>
          </section>
        )}

        {/* FAQ */}
        {currentPage === 'faq' && (
          <section className="py-16 bg-white">
            <div className="container mx-auto px-4 max-w-4xl">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700">Frequently Asked Questions</h1>
                <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-indigo-600 mx-auto rounded-full" />
              </div>
              <div className="space-y-6">
                {FAQ_ITEMS.map((faq, i) => <FAQItem key={i} question={faq.question} answer={faq.answer} />)}
              </div>
            </div>
          </section>
        )}

        {/* CONTACT */}
        {currentPage === 'contact' && (
          <section className="py-16 bg-white">
            <div className="container mx-auto px-4 max-w-3xl">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700">Contact Us</h1>
                <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-indigo-600 mx-auto rounded-full" />
              </div>
              <div className="bg-gray-50 rounded-2xl p-8 md:p-12 shadow-md text-center">
                <div className="text-6xl mb-6">📬</div>
                <h2 className="text-2xl font-bold mb-4 text-gray-800">We'd love to hear from you!</h2>
                <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">Have questions, feedback, or suggestions? We're here to help make your job application process smoother.</p>
                <a href="mailto:support@resume-refine.com"
                  className="inline-block bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-bold text-xl py-4 px-10 rounded-xl hover:from-blue-700 hover:to-indigo-800 transition duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                  Email Us: support@resume-refine.com
                </a>
                <p className="mt-8 text-gray-600 text-lg">We respond to all inquiries within 24 hours.</p>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4 text-center">
          <div className="text-2xl font-bold mb-4">Resume Refine</div>
          <p className="text-gray-300 max-w-2xl mx-auto mb-6">Making job applications faster, easier, and stress-free for students and first-time job seekers.</p>
          <div className="flex flex-wrap justify-center gap-6 mb-6">
            {NAV_PAGES.map((page) => (
              <button key={page} onClick={() => setCurrentPage(page)} className="text-gray-300 hover:text-white font-medium transition-colors">
                {page.charAt(0).toUpperCase() + page.slice(1)}
              </button>
            ))}
          </div>
          <div className="text-gray-500 text-sm border-t border-gray-800 pt-6">
            <p>© {new Date().getFullYear()} Resume Refine. All rights reserved.</p>
            <p className="mt-1">Your data is never stored. Processed securely in real-time.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
